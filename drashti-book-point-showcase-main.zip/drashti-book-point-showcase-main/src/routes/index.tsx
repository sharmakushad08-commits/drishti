import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { About } from "@/components/site/About";
import { Gallery } from "@/components/site/Gallery";
import { Reviews } from "@/components/site/Reviews";
import { Visit } from "@/components/site/Visit";
import { Footer } from "@/components/site/Footer";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Drishti Book Point & Stationery · Sikar, Rajasthan" },
      { name: "description", content: "Drishti Book Point & Stationery in Sikar — books, premium stationery, journals, competition study material and online form services on Nawalgarh Road." },
      { property: "og:title", content: "Drishti Book Point & Stationery · Sikar" },
      { property: "og:description", content: "We give Drishti — direction to the young generation. Visit our shop on Nawalgarh Road, Sikar." },
      { property: "og:type", content: "website" },
    ],
  }),
});

function Index() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <Hero />
      <About />
      <Gallery />
      <Reviews />
      <Visit />
      <Footer />
      <Toaster />
    </main>
  );
}
