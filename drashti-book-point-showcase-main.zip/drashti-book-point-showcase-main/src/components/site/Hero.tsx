import booksPens from "@/assets/books-pens.jpg";

export function Hero() {
  return (
    <section id="home" className="relative min-h-screen pt-28 pb-20 overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
      <div className="absolute -top-40 -right-40 h-[500px] w-[500px] rounded-full bg-primary/20 blur-3xl" />
      <div className="absolute -bottom-40 -left-40 h-[500px] w-[500px] rounded-full bg-accent/20 blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-6 grid lg:grid-cols-[1.1fr_1fr] gap-14 items-center">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full bg-card/70 backdrop-blur px-4 py-1.5 text-xs tracking-widest uppercase text-muted-foreground border border-border">
            <span className="h-1.5 w-1.5 rounded-full bg-primary" />
            Sikar · Rajasthan · Est. Nawalgarh Road
          </span>
          <h1 className="mt-7 font-display text-5xl sm:text-6xl lg:text-7xl leading-[1.02]">
            We give <em className="text-primary not-italic">Drishti</em>
            <br />
            — direction to the
            <br /> young generation.
          </h1>
          <p className="mt-7 text-lg text-muted-foreground max-w-xl leading-relaxed">
            Drishti Book Point &amp; Stationery — a quiet corner for students, dreamers and readers.
            We stock the complete <span className="text-foreground font-medium">NCERT, JEE and NEET</span> range,
            alongside beautiful journals and everyday stationery.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <a href="#visit" className="rounded-full bg-primary text-primary-foreground px-7 py-3.5 text-sm font-medium shadow-[var(--shadow-soft)] hover:-translate-y-0.5 transition-transform">
              Visit the Shop
            </a>
            <a href="#reviews" className="rounded-full border border-foreground/20 px-7 py-3.5 text-sm font-medium hover:bg-foreground hover:text-background transition-colors">
              Read Reviews
            </a>
          </div>
          <dl className="mt-12 grid grid-cols-3 gap-6 max-w-md">
            <div>
              <dt className="text-xs uppercase tracking-widest text-muted-foreground">Open</dt>
              <dd className="mt-1 font-display text-2xl">6:30 – 22:30</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-widest text-muted-foreground">Days</dt>
              <dd className="mt-1 font-display text-2xl">All 7</dd>
            </div>
            <div>
              <dt className="text-xs uppercase tracking-widest text-muted-foreground">Since</dt>
              <dd className="mt-1 font-display text-2xl">Sikar</dd>
            </div>
          </dl>
        </div>

        <div className="relative">
          <div className="absolute -inset-6 rounded-[2rem] bg-primary/10 rotate-[-3deg]" />
          <div className="relative overflow-hidden rounded-[2rem] shadow-[var(--shadow-soft)] aspect-[4/5]">
            <img src={booksPens} alt="Aesthetic stack of books, journal and fountain pen" className="h-full w-full object-cover" />
          </div>
          <div className="absolute -bottom-6 -left-6 bg-card rounded-2xl p-5 shadow-[var(--shadow-warm)] max-w-[220px] border border-border">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Today</p>
            <p className="mt-1 font-display text-lg">Books · Stationery · Online Forms</p>
          </div>
        </div>
      </div>
    </section>
  );
}
