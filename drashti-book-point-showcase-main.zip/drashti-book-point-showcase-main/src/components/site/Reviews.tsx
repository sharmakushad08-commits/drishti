import { useEffect, useState } from "react";
import { Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type Review = { id: string; name: string; rating: number; message: string; created_at: string };

const seed: Review[] = [
  { id: "s1", name: "Aavya Sharma", rating: 5, message: "The aesthetic of this place is unmatched. Found the perfect pastel highlighters and some really unique washi tapes.", created_at: "" },
  { id: "s2", name: "Rohan Mehra", rating: 5, message: "The quality of the fountain pen paper here is excellent. No bleed-through at all.", created_at: "" },
  { id: "s3", name: "Ananya Iyer", rating: 5, message: "Honestly, the best place for journal lovers. Their handmade paper collection is stunning.", created_at: "" },
  { id: "s4", name: "Ishaan Malhotra", rating: 5, message: "Found some high-end professional markers that are usually hard to find in India. Great stock!", created_at: "" },
  { id: "s5", name: "Sana Khan", rating: 5, message: "Beautifully curated shop. It's a paradise for anyone who loves organized desks.", created_at: "" },
  { id: "s6", name: "Vikram Singh", rating: 5, message: "Top-notch quality. Even the basic ballpoints feel premium here.", created_at: "" },
  { id: "s7", name: "Rahul Verma", rating: 5, message: "Best prices in the neighborhood for bulk notebook sets. Very helpful for college students.", created_at: "" },
  { id: "s8", name: "Aditya Nair", rating: 5, message: "Great discounts on exam boards and geometry boxes. Highly recommended.", created_at: "" },
  { id: "s9", name: "Kriti Sharma", rating: 5, message: "The spiral notebooks here have very thick pages. Perfect for my coaching notes.", created_at: "" },
];

function Stars({ value, onChange }: { value: number; onChange?: (n: number) => void }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          onClick={() => onChange?.(n)}
          className={`transition ${onChange ? "cursor-pointer" : "cursor-default"}`}
          aria-label={`${n} star`}
        >
          <Star className={`h-5 w-5 ${n <= value ? "fill-primary text-primary" : "text-muted-foreground/40"}`} />
        </button>
      ))}
    </div>
  );
}

export function Reviews() {
  const [userReviews, setUserReviews] = useState<Review[]>([]);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [rating, setRating] = useState(5);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const { data } = await supabase.from("reviews").select("*").order("created_at", { ascending: false }).limit(30);
    if (data) setUserReviews(data as Review[]);
  };

  useEffect(() => { load(); }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return toast.error("Please fill in your name and review.");
    setLoading(true);
    const { error } = await supabase.from("reviews").insert({ name: name.trim(), message: message.trim(), rating });
    setLoading(false);
    if (error) return toast.error("Could not post review. Try again.");
    toast.success("Thank you for your review!");
    setName(""); setMessage(""); setRating(5);
    load();
  };

  const all = [...userReviews, ...seed];

  return (
    <section id="reviews" className="py-28 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-[0.25em] text-primary">What people say</span>
          <h2 className="mt-3 font-display text-4xl sm:text-5xl">Kind words from our shelves.</h2>
        </div>

        <div className="grid lg:grid-cols-[1.5fr_1fr] gap-12">
          <div className="grid sm:grid-cols-2 gap-5 content-start">
            {all.slice(0, 10).map((r) => (
              <article key={r.id} className="rounded-3xl bg-card border border-border p-7 hover:shadow-[var(--shadow-warm)] transition-shadow">
                <Stars value={r.rating} />
                <p className="mt-4 text-[15px] leading-relaxed text-foreground/90">"{r.message}"</p>
                <p className="mt-5 font-display text-lg">{r.name}</p>
              </article>
            ))}
          </div>

          <form onSubmit={submit} className="rounded-3xl bg-secondary/60 border border-border p-8 h-fit lg:sticky lg:top-28">
            <h3 className="font-display text-2xl">Leave a review</h3>
            <p className="text-sm text-muted-foreground mt-1">Visited Drishti? We'd love to hear from you.</p>

            <label className="block mt-6 text-xs uppercase tracking-widest text-muted-foreground">Your name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={80}
              className="mt-2 w-full rounded-xl bg-card border border-border px-4 py-3 outline-none focus:ring-2 ring-primary"
              placeholder="e.g. Priya S."
            />

            <label className="block mt-5 text-xs uppercase tracking-widest text-muted-foreground">Rating</label>
            <div className="mt-2"><Stars value={rating} onChange={setRating} /></div>

            <label className="block mt-5 text-xs uppercase tracking-widest text-muted-foreground">Your review</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              maxLength={1000}
              rows={5}
              className="mt-2 w-full rounded-xl bg-card border border-border px-4 py-3 outline-none focus:ring-2 ring-primary resize-none"
              placeholder="Tell us what you loved…"
            />

            <button
              disabled={loading}
              className="mt-6 w-full rounded-full bg-primary text-primary-foreground py-3 text-sm font-medium disabled:opacity-60 hover:-translate-y-0.5 transition-transform shadow-[var(--shadow-soft)]"
            >
              {loading ? "Posting…" : "Post review"}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
