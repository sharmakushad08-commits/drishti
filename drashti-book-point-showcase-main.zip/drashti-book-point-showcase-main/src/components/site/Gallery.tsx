import img1 from "@/assets/shop-interior-1.jpg";
import img2 from "@/assets/shop-interior-2.jpg";
import img3 from "@/assets/shop-interior-3.jpg";
import img4 from "@/assets/shop-entrance.jpg";
import img5 from "@/assets/shop-front.jpg";

export function Gallery() {
  return (
    <section id="gallery" className="py-28 px-6 bg-secondary/40">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-12">
          <div>
            <span className="text-xs uppercase tracking-[0.25em] text-primary">Inside Drishti</span>
            <h2 className="mt-3 font-display text-4xl sm:text-5xl">A peek through the shutters.</h2>
          </div>
          <p className="text-muted-foreground max-w-sm">
            Opposite Udhyog Nagar Police Station, Nawalgarh Road — where a warm "Welcome" greets every student.
          </p>
        </div>

        <div className="grid grid-cols-6 grid-rows-2 gap-4 h-[640px]">
          <figure className="col-span-3 row-span-2 rounded-3xl overflow-hidden">
            <img src={img1} alt="Drishti Book Point shopfront" className="h-full w-full object-cover hover:scale-105 transition-transform duration-700" />
          </figure>
          <figure className="col-span-3 row-span-1 rounded-3xl overflow-hidden">
            <img src={img2} alt="Shop lit up at night" className="h-full w-full object-cover hover:scale-105 transition-transform duration-700" />
          </figure>
          <figure className="col-span-2 row-span-1 rounded-3xl overflow-hidden">
            <img src={img3} alt="Welcome counter with students" className="h-full w-full object-cover hover:scale-105 transition-transform duration-700" />
          </figure>
          <figure className="col-span-1 row-span-1 rounded-3xl overflow-hidden bg-card border border-border grid place-items-center p-5 text-center">
            <div>
              <p className="font-display text-3xl text-primary">7</p>
              <p className="text-xs uppercase tracking-widest text-muted-foreground mt-1">Days open</p>
            </div>
          </figure>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mt-4">
          <figure className="rounded-3xl overflow-hidden aspect-[16/9]">
            <img src={img4} alt="Stationery counter and book shelves" className="h-full w-full object-cover hover:scale-105 transition-transform duration-700" />
          </figure>
          <figure className="rounded-3xl overflow-hidden aspect-[16/9]">
            <img src={img5} alt="Entrance of Drishti Book Point" className="h-full w-full object-cover hover:scale-105 transition-transform duration-700" />
          </figure>
        </div>
      </div>
    </section>
  );
}
