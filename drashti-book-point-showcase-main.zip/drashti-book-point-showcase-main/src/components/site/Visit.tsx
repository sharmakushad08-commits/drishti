import { MapPin, Phone, Clock } from "lucide-react";

const hours = [
  ["Monday", "6:30 am – 10:30 pm"],
  ["Tuesday", "6:30 am – 10:30 pm"],
  ["Wednesday", "6:30 am – 10:30 pm"],
  ["Thursday", "6:30 am – 10:30 pm"],
  ["Friday", "6:30 am – 10:30 pm"],
  ["Saturday", "6:30 am – 10:30 pm"],
  ["Sunday", "6:30 am – 10:30 pm"],
];

export function Visit() {
  const mapsQuery = encodeURIComponent("Drishti Book Point & Stationery, Nawalgarh Rd, Charan Singh Nagar, Sikar, Rajasthan 332001");
  return (
    <section id="visit" className="py-28 px-6 bg-primary/8" style={{ background: "linear-gradient(180deg, transparent, color-mix(in oklab, var(--sage) 12%, transparent))" }}>
      <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-start">
        <div>
          <span className="text-xs uppercase tracking-[0.25em] text-primary">Visit us</span>
          <h2 className="mt-3 font-display text-4xl sm:text-5xl leading-tight">
            Come say hello on
            <br /> Nawalgarh Road.
          </h2>

          <div className="mt-10 space-y-6">
            <div className="flex gap-4">
              <span className="h-11 w-11 shrink-0 rounded-2xl bg-card border border-border grid place-items-center">
                <MapPin className="h-5 w-5 text-primary" />
              </span>
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">Address</p>
                <p className="mt-1 leading-relaxed">
                  Drishti Book Point &amp; Stationery,<br />
                  Nawalgarh Rd, near Shree Krishna Residency,<br />
                  Charan Singh Nagar, Sikar, Rajasthan 332001
                </p>
                <a
                  target="_blank" rel="noopener noreferrer"
                  href={`https://www.google.com/maps/search/?api=1&query=${mapsQuery}`}
                  className="inline-block mt-2 text-sm text-primary hover:underline"
                >
                  Open in Google Maps →
                </a>
              </div>
            </div>

            <div className="flex gap-4">
              <span className="h-11 w-11 shrink-0 rounded-2xl bg-card border border-border grid place-items-center">
                <Phone className="h-5 w-5 text-primary" />
              </span>
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">Phone</p>
                <a href="tel:+919461581580" className="mt-1 block font-display text-2xl hover:text-primary">+91 94615 81580</a>
              </div>
            </div>

            <div className="flex gap-4">
              <span className="h-11 w-11 shrink-0 rounded-2xl bg-card border border-border grid place-items-center">
                <Clock className="h-5 w-5 text-primary" />
              </span>
              <div className="w-full">
                <p className="text-xs uppercase tracking-widest text-muted-foreground">Hours</p>
                <ul className="mt-2 divide-y divide-border rounded-2xl bg-card border border-border overflow-hidden">
                  {hours.map(([d, h]) => (
                    <li key={d} className="flex justify-between px-5 py-3 text-sm">
                      <span className="text-muted-foreground">{d}</span>
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-3xl overflow-hidden shadow-[var(--shadow-soft)] border border-border aspect-square lg:aspect-auto lg:h-[640px]">
          <iframe
            title="Drishti Book Point location"
            src={`https://www.google.com/maps?q=${mapsQuery}&output=embed`}
            className="w-full h-full"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}
