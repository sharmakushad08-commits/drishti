import { BookOpen, PenLine, GraduationCap, FileText } from "lucide-react";

const items = [
  { icon: BookOpen, title: "NCERT · JEE · NEET", text: "Complete NCERT sets (Class 1–12), JEE preparation books and the full range of NEET study material — all under one roof." },
  { icon: PenLine, title: "Premium Stationery", text: "Fountain-pen paper, pastel highlighters, washi tapes, handmade journals." },
  { icon: GraduationCap, title: "Competition & College", text: "SSC, Bank, Railway, LDC, CET, UPSC, Police — thick-page notebooks, geometry boxes, exam boards." },
  { icon: FileText, title: "Drishti e-Mitra", text: "All online form filling, photocopy, lamination, binding — done in-shop." },
];

export function About() {
  return (
    <section id="about" className="py-28 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-[1fr_1.4fr] gap-16 items-start">
          <div className="lg:sticky lg:top-32">
            <span className="text-xs uppercase tracking-[0.25em] text-primary">About the shop</span>
            <h2 className="mt-4 font-display text-4xl sm:text-5xl leading-tight">
              A small shop with
              <br /> a big sense of purpose.
            </h2>
            <p className="mt-6 text-muted-foreground leading-relaxed">
              For years, Drishti Book Point has quietly served the students of Sikar — stocking
              everything from the thickest coaching notebooks to the most delicate handmade papers.
              We believe a good pen and the right book can change a life.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            {items.map(({ icon: Icon, title, text }) => (
              <div
                key={title}
                className="group rounded-3xl bg-card border border-border p-7 hover:shadow-[var(--shadow-soft)] hover:-translate-y-1 transition-all duration-300"
              >
                <span className="h-11 w-11 rounded-2xl bg-secondary grid place-items-center text-foreground">
                  <Icon className="h-5 w-5" />
                </span>
                <h3 className="mt-5 font-display text-xl">{title}</h3>
                <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
