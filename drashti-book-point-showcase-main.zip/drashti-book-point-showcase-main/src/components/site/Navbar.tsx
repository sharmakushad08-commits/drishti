import { useState, useEffect } from "react";
import { BookOpen } from "lucide-react";

const links = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#gallery", label: "Gallery" },
  { href: "#reviews", label: "Reviews" },
  { href: "#visit", label: "Visit" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "bg-background/80 backdrop-blur-xl border-b border-border/60" : "bg-transparent"
      }`}
    >
      <nav className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
        <a href="#home" className="flex items-center gap-2.5">
          <span className="h-9 w-9 rounded-full bg-primary text-primary-foreground grid place-items-center">
            <BookOpen className="h-4 w-4" />
          </span>
          <span className="font-display text-xl tracking-tight">Drishti</span>
        </a>
        <ul className="hidden md:flex items-center gap-9 text-sm text-muted-foreground">
          {links.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="hover:text-foreground transition-colors">
                {l.label}
              </a>
            </li>
          ))}
        </ul>
        <a
          href="tel:+919461581580"
          className="hidden sm:inline-flex items-center rounded-full bg-foreground text-background px-5 py-2 text-sm hover:opacity-90 transition"
        >
          Call Shop
        </a>
      </nav>
    </header>
  );
}
