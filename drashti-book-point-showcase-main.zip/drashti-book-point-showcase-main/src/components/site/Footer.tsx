export function Footer() {
  return (
    <footer className="border-t border-border py-10 px-6">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <p className="font-display text-base text-foreground">Drishti Book Point &amp; Stationery</p>
        <p>© {new Date().getFullYear()} · Nawalgarh Road, Sikar · Giving direction since day one.</p>
      </div>
    </footer>
  );
}
